/* =========================================
 * Q3 — Gravity Falls: Diário, Criaturas e CabanaMistério
 * Conceitos: encapsulamento (campo privado), Map, agregação/composição
 * ========================================= */

// --------- Diário (usa Map e campo privado) ---------
class Diario {
  #autorSecreto;                // usado como “chave mestre”
  enigmas = new Map();          // Map<Number, String>
  criaturasAvistadas = [];      // Array<Criatura> (agregação)

  constructor(autor) {
    if (!autor) throw new Error("Autor do Diário é obrigatório.");
    this.#autorSecreto = String(autor);
  }

  getAutor() {
    // expõe sem vazar o valor real
    return this.#autorSecreto.replace(/./g, "*");
  }

  adicionarEnigma(num, enigma) {
    const k = Number(num);
    if (!Number.isFinite(k)) throw new Error("Número do enigma inválido.");
    this.enigmas.set(k, String(enigma));
  }

  /**
   * decodificar(chave, num): valida pelo #autorSecreto e pelo índice
   * - chave incorreta => "ACESSO NEGADO"
   * - índice inexistente => "ENIGMA INEXISTENTE"
   * - ok => retorna string com o enigma
   */
  decodificar(chave, num) {
    if (String(chave) !== this.#autorSecreto) return "ACESSO NEGADO";
    const k = Number(num);
    if (!this.enigmas.has(k)) return "ENIGMA INEXISTENTE";
    return this.enigmas.get(k);
  }
}

// --------- Criatura ---------
class Criatura {
  constructor(nome, perigosa = false) {
    this.nome = String(nome);
    this.perigosa = Boolean(perigosa);
  }
  toString() {
    return `${this.nome}${this.perigosa ? " (perigosa)" : ""}`;
  }
}

// --------- Personagem (base) & Protagonista (tem Diário) ---------
class Personagem {
  constructor(nome, idade) {
    this.nome = String(nome);
    this.idade = Number(idade) || 0;
  }
  toString() {
    return `${this.nome} (${this.idade} anos)`;
  }
}

class Protagonista extends Personagem {
  constructor(nome, idade, diario) {
    super(nome, idade);
    if (!(diario instanceof Diario)) {
      throw new Error("Protagonista requer um Diário válido.");
    }
    this.diario = diario; // composição
  }
}

// --------- CabanaMistério (agrega Personagens funcionários) ---------
class CabanaMisterio {
  visitantes = [];     // Array<String>
  #funcionarios = [];  // Array<Personagem> (agregação)

  constructor(diario) {
    // referência para eventual consulta (opcional)
    if (!(diario instanceof Diario)) {
      throw new Error("CabanaMistério requer um Diário válido.");
    }
    this.diario = diario;
  }

  adicionarFuncionario(p) {
    if (!(p instanceof Personagem)) {
      throw new Error("Funcionário precisa ser um Personagem.");
    }
    this.#funcionarios.push(p);
  }

  // 2 & 3) Deve retornar a coleção agregada de Personagens (cópia defensiva)
  listarFuncionarios() {
    return this.#funcionarios.slice();
  }
}

/* ========= UI mínima para seu index.html ========= */

const out = document.getElementById("out");
const log = (s = "") => (out.textContent += s + "\n");

document.getElementById("rodar").addEventListener("click", () => {
  out.textContent = "";

  // Monta Diário e enigmas
  const diario = new Diario("DipperPines#42");
  diario.adicionarEnigma(1, "Criptograma do Baphomet reverso.");
  diario.adicionarEnigma(2, "Símbolos do Bill Cipher perto da cabana.");

  // Criaturas (exemplo de agregação no diário)
  diario.criaturasAvistadas.push(new Criatura("Gnomos", false));
  diario.criaturasAvistadas.push(new Criatura("Bill Cipher", true));

  // Protagonista (tem o diário)
  const dipper = new Protagonista("Dipper", 12, diario);

  // Cabana Mistério agregando funcionários
  const cabana = new CabanaMisterio(diario);
  cabana.adicionarFuncionario(dipper);
  cabana.adicionarFuncionario(new Personagem("Mabel", 12));
  cabana.adicionarFuncionario(new Personagem("Soos", 22));
  cabana.adicionarFuncionario(new Personagem("Wendy", 15));

  // Saída
  log("— Funcionários da Cabana —");
  cabana.listarFuncionarios().forEach((p) => log("• " + p.toString()));

  log("\n— Criaturas vistas no Diário —");
  diario.criaturasAvistadas.forEach((c) => log("• " + c.toString()));

  log("\n— Decodificação de Enigmas —");
  log("Chave errada: " + diario.decodificar("senhaErrada", 1));
  log("Chave certa (1): " + diario.decodificar("DipperPines#42", 1));
  log("Chave certa (2): " + diario.decodificar("DipperPines#42", 2));
});
