/* ===============================
 * Q2 — Esquadrão do Capitão Levi
 * POO com composição, agregação e “contrato” por duck-typing
 * =============================== */

// ---------- “Interface” IExplorador (duck-typing) ----------
function implementsIExplorador(obj) {
  return obj && typeof obj.explorarTerritorio === "function";
}

// ---------- Componente essencial do Soldado ----------
class ODM_Gear {
  #gasRestante;

  constructor(modelo) {
    if (!modelo) throw new Error("Modelo do ODM_Gear é obrigatório.");
    this.modelo = modelo;
    this.#gasRestante = 100; // 0..100
  }

  usarGas(quantidade) {
    const q = Math.max(0, Number(quantidade) || 0);
    const consumido = Math.min(q, this.#gasRestante);
    this.#gasRestante -= consumido;
    return consumido;
  }

  getGas() {
    return this.#gasRestante;
  }

  toString() {
    return `ODM(${this.modelo}) — Gás: ${this.getGas()}%`;
  }
}

// ---------- Soldado (compõe ODM_Gear) ----------
class Soldado {
  constructor(nome, modeloGear) {
    if (!nome) throw new Error("Nome do Soldado é obrigatório.");
    this.nome = nome;
    this.gear = new ODM_Gear(modeloGear);
  }

  explorarTerritorio() {
    if (this.gear.getGas() <= 0) {
      return `${this.nome}: sem gás para explorar.`;
    }
    // custo padrão de uma “exploração”
    const custo = 15;
    const gasto = this.gear.usarGas(custo);
    return `${this.nome} explorou o perímetro (gasto ${gasto} de gás).`;
  }

  verificarEquipamento() {
    return `${this.nome} — ${this.gear.toString()}`;
  }

  toString() {
    return `${this.nome} com ${this.gear.toString()}`;
  }
}

// ---------- Esquadrão (agrega vários Soldados) ----------
class Esquadrao {
  constructor(lider, membrosIniciais = []) {
    if (!implementsIExplorador(lider)) {
      throw new Error("Líder deve implementar IExplorador (ex.: Soldado).");
    }
    this.lider = lider;
    this.membros = [];

    this.adicionarMembro(lider); // liderança também compõe o time
    membrosIniciais.forEach((m) => this.adicionarMembro(m));
  }

  adicionarMembro(soldado) {
    if (!implementsIExplorador(soldado)) {
      throw new Error("Membro inválido: não implementa IExplorador.");
    }
    this.membros.push(soldado);
  }

  explorarTerritorio() {
    // chama o método do Soldado que, por sua vez, usa o ODM_Gear internamente
    return this.membros.map((s) => s.explorarTerritorio());
  }

  relatarStatus() {
    return this.membros.map((s) => s.verificarEquipamento());
  }
}

/* ===============================
 * UI mínima (integra ao index.html)
 * =============================== */

const out = document.getElementById("out");
const log = (s = "") => (out.textContent += s + "\n");

document.getElementById("rodar").addEventListener("click", () => {
  out.textContent = "";

  // Exemplos de soldados
  const levi = new Soldado("Levi", "ODM-Mikasa");
  const mikasa = new Soldado("Mikasa", "ODM-Ackerman");
  const armin = new Soldado("Armin", "ODM-Scout");

  // Esquadrão do Levi
  const esquadrao = new Esquadrao(levi, [mikasa, armin]);

  log("— Status inicial —");
  esquadrao.relatarStatus().forEach((s) => log(s));

  log("\n— Exploração —");
  esquadrao.explorarTerritorio().forEach((r) => log(r));

  log("\n— Status após missão —");
  esquadrao.relatarStatus().forEach((s) => log(s));
});

// Exporte para testes se usar Node/ESM:
// export { ODM_Gear, Soldado, Esquadrao, implementsIExplorador };
