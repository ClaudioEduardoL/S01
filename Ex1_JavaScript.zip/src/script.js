// classes (POO) — exemplo mínimo
class Pokemon {
  #vida;
  constructor(nome, tipo, vidaInicial) { this.nome = nome; this.tipo = tipo; this.#vida = vidaInicial; }
  getVida() { return this.#vida; }
  receberDano(d) { this.#vida = Math.max(0, this.#vida - d); }
  atacar(alvo) { const dano = 5; alvo.receberDano(dano); return `${this.nome} causou ${dano} em ${alvo.nome}`; }
  toString() { return `${this.nome} [${this.tipo}] — Vida: ${this.getVida()}`; }
}

class PokemonFogo extends Pokemon {
  atacar(alvo) { const dano = 10; alvo.receberDano(dano); return `${this.nome} usou Lança-Chamas em ${alvo.nome} (${dano})`; }
}

class PokemonAgua extends Pokemon {
  atacar(alvo) { const dano = 8; alvo.receberDano(dano); return `${this.nome} usou Jato d'Água em ${alvo.nome} (${dano})`; }
}

// “resposta” na página
const out = document.getElementById('out');
const log = (s='') => out.textContent += s + '\n';

document.getElementById('rodar').addEventListener('click', () => {
  out.textContent = '';
  const charmander = new PokemonFogo('Charmander', 'Fogo', 30);
  const squirtle   = new PokemonAgua('Squirtle', 'Água', 28);

  log(charmander.toString());
  log(squirtle.toString());
  log(charmander.atacar(squirtle));
  log(squirtle.toString());
  log(squirtle.atacar(charmander));
  log(charmander.toString());
});
