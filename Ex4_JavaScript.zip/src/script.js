/* =========================================================
 * Q4 — Associação Hunter
 * Conceitos: herança, polimorfismo, composição leve, Set p/ unicidade
 * Interface IRastreável via duck-typing (rastrearLocal)
 * ========================================================= */

// ---------- Função utilitária para “interface” IRastreável ----------
function implementsIRastreavel(o) {
  return o && typeof o.rastrearLocal === "function";
}

// ---------- Classe base Hunter ----------
class Hunter {
  #nome;
  #idade;
  #localizacao;

  constructor(nome, local = "Desconhecido", idade = 0) {
    if (!nome) throw new Error("Nome do Hunter é obrigatório.");
    this.#nome = String(nome);
    this.#localizacao = String(local);
    this.#idade = Number(idade) || 0;
  }

  get nome() { return this.#nome; }
  get idade() { return this.#idade; }
  get localizacao() { return this.#localizacao; }
  set localizacao(v) { this.#localizacao = String(v); }

  // “abstrato”: subclasses devem sobrescrever
  rastrearLocal(lat, long) {
    throw new Error("Subclasse deve implementar rastrearLocal(lat,long).");
  }

  toString() {
    return `${this.nome} (${this.idade}) @ ${this.localizacao}`;
  }
}

// ---------- Especialista ----------
class Especialista extends Hunter {
  #habilidadeNen;

  constructor(nome, habilidadeNen, local = "QG", idade = 0) {
    super(nome, local, idade);
    this.#habilidadeNen = String(habilidadeNen || "Nen desconhecido");
  }

  rastrearLocal(lat, long) {
    const pos = `${lat},${long}`;
    this.localizacao = pos;
    return `Especialista ${this.nome} (Nen: ${this.#habilidadeNen}) rastreou para ${pos}.`;
  }
}

// ---------- Manipulador ----------
class Manipulador extends Hunter {
  #alvoAtual; // pode ser outro Hunter (composição leve)

  constructor(nome, local = "Campo", idade = 0) {
    super(nome, local, idade);
    this.#alvoAtual = null;
  }

  definirAlvo(hunter) {
    if (!(hunter instanceof Hunter)) {
      throw new Error("Alvo deve ser um Hunter.");
    }
    this.#alvoAtual = hunter;
  }

  rastrearLocal(lat, long) {
    const pos = `${lat},${long}`;
    this.localizacao = pos;

    const alvoTxt = this.#alvoAtual ? ` (seguindo ${this.#alvoAtual.nome})` : "";
    return `Manipulador ${this.nome}${alvoTxt} moveu-se para ${pos}.`;
  }
}

// ---------- Batalhão (usa Set para não duplicar Hunters por nome) ----------
class Batalhao {
  #hunters;      // Set< Hunter >
  #nomesUsados;  // Set< string > para garantir unicidade por nome

  constructor() {
    this.#hunters = new Set();
    this.#nomesUsados = new Set();
  }

  adicionarHunter(hunter) {
    if (!(hunter instanceof Hunter)) {
      throw new Error("Somente instâncias de Hunter podem ser adicionadas.");
    }
    if (this.#nomesUsados.has(hunter.nome)) {
      // ignora duplicação por nome (requisito do enunciado)
      return false;
    }
    this.#hunters.add(hunter);
    this.#nomesUsados.add(hunter.nome);
    return true;
  }

  getNumHunters() {
    return this.#hunters.size;
  }

  /**
   * Itera sobre o Set e chama o método polimórfico rastrearLocal()
   * em cada Hunter, retornando um Array<String> com os relatos.
   */
  iniciarRastreamento(lat, long) {
    const latS = String(lat), longS = String(long);
    const saidas = [];
    for (const h of this.#hunters) {
      if (implementsIRastreavel(h)) {
        saidas.push(h.rastrearLocal(latS, longS));
      }
    }
    return saidas;
  }

  listar() {
    return Array.from(this.#hunters).map(h => h.toString());
  }
}

/* ================== UI mínima para seu index.html ================== */

const out = document.getElementById("out");
const log = (s = "") => (out.textContent += s + "\n");

document.getElementById("rodar").addEventListener("click", () => {
  out.textContent = "";

  // Cria Hunters
  const kurapika = new Especialista("Kurapika", "Correntes", "Yorknew", 19);
  const illumi    = new Manipulador("Illumi", "HQ Zoldyck", 20);
  const shalnark  = new Manipulador("Shalnark", "Meteor City", 17);

  // Relação de alvo (exemplo de composição leve)
  illumi.definirAlvo(kurapika);

  // Batalhão com controle de duplicidade por nome
  const batalhao = new Batalhao();
  batalhao.adicionarHunter(kurapika);
  batalhao.adicionarHunter(illumi);
  batalhao.adicionarHunter(shalnark);
  batalhao.adicionarHunter(new Especialista("Kurapika", "Correntes v2")); // duplicado: ignorado

  log("— Batalhão (sem duplicados) —");
  batalhao.listar().forEach(s => log("• " + s));
  log(`Total: ${batalhao.getNumHunters()} hunters\n`);

  log("— Rastreamento —");
  batalhao.iniciarRastreamento("-23.55", "-46.63").forEach(r => log(r));
});

// Exporte para testes se usar Node/ESM:
// export { Hunter, Especialista, Manipulador, Batalhao, implementsIRastreavel };
